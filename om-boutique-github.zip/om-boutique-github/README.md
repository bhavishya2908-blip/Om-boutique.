# Om Boutique

A responsive single-page boutique website built with HTML, CSS, and vanilla JavaScript.

## Run locally
1. Download and extract this folder.
2. Open `index.html` in a modern browser.
3. For a local development server, you can use VS Code's Live Server extension.

## Optional service setup

The website includes optional integrations that are not active until configured:

### Measurement form (Web3Forms)
- Create a Web3Forms access key from https://web3forms.com/
- In `index.html`, replace `PASTE_YOUR_WEB3FORMS_ACCESS_KEY_HERE` with your access key.
- The current placeholder means online submission will not work yet. The Copy details option can still be used.

### Login (Supabase)
- Create a Supabase project at https://supabase.com/
- Replace `PASTE_YOUR_SUPABASE_PROJECT_URL` and `PASTE_YOUR_SUPABASE_ANON_KEY` in `index.html` with your project's URL and public anon/publishable key.
- Configure Supabase Auth email settings and allowed redirect URLs for your deployed domain.
- Never put a Supabase service-role key or other private server secret in frontend code. The anon/publishable key is designed for browser use, but database access must be protected with Row Level Security (RLS).

## Before publishing
- Verify the shop address, opening hours, phone number, email address, product descriptions, prices, and shipping promise.
- Add real product photos and update the "Coming soon" labels when products are ready.
- Test the measurement form and authentication after configuring their providers.
- Consider moving CSS and JavaScript into separate files as the site grows.

## Deploy with GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`, `README.md`, and `.gitignore` (or push this folder with Git).
3. In GitHub, open **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for the deployment link to appear in the Pages settings.

This is a static frontend. It does not currently include product inventory, checkout, order management, or a secure backend for storing customer measurements.
